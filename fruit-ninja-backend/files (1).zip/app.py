"""
Fruit Ninja YOLO Backend Server
Detects hands using YOLO and processes fruit slicing with CUDA support
"""

import os
import sys
import cv2
import numpy as np
import torch
import logging
from flask import Flask, request, jsonify
from flask_cors import CORS
from datetime import datetime
from typing import Optional
import base64
from io import BytesIO
from PIL import Image

# Import custom modules
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from hand_detector import HandDetector
from fruit_slicer import FruitSlicer
from utils import (
    setup_logging,
    load_config,
    validate_input_image,
    encode_image_to_base64,
)

# Initialize Flask app
app = Flask(__name__)
CORS(app)

# Setup logging
logger = setup_logging()

# Load configuration
config = load_config()

# Global objects
hand_detector = None
fruit_slicer = None
device = None


def initialize_models():
    """Initialize YOLO hand detector and fruit slicer with CUDA support"""
    global hand_detector, fruit_slicer, device

    try:
        # Detect available device
        if torch.cuda.is_available():
            device = torch.device('cuda:0')
            logger.info(f"Using CUDA: {torch.cuda.get_device_name(0)}")
            logger.info(f"CUDA Version: {torch.version.cuda}")
        else:
            device = torch.device('cpu')
            logger.warning("CUDA not available. Using CPU for inference.")

        # Initialize hand detector
        logger.info("Loading YOLO hand detection model...")
        hand_detector = HandDetector(
            model_path=config['hand_detector']['model_path'],
            confidence_threshold=config['hand_detector']['confidence_threshold'],
            device=device
        )
        logger.info("Hand detector initialized successfully")

        # Initialize fruit slicer
        logger.info("Initializing fruit slicer...")
        fruit_slicer = FruitSlicer(
            motion_threshold=config['fruit_slicer']['motion_threshold'],
            max_trail_length=config['fruit_slicer']['max_trail_length'],
            device=device
        )
        logger.info("Fruit slicer initialized successfully")

    except Exception as e:
        logger.error(f"Error initializing models: {str(e)}")
        raise


@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'device': str(device),
        'cuda_available': torch.cuda.is_available(),
        'models_loaded': hand_detector is not None and fruit_slicer is not None,
        'timestamp': datetime.now().isoformat()
    }), 200


@app.route('/detect', methods=['POST'])
def detect_hand():
    """
    Detect hand in image
    Expects: JSON with 'image' field (base64 encoded) or file upload
    Returns: Hand detections with bounding boxes and confidence scores
    """
    try:
        if hand_detector is None:
            return jsonify({'error': 'Hand detector not initialized'}), 500

        # Get image from request
        image = _get_image_from_request(request)
        if image is None:
            return jsonify({'error': 'No valid image provided'}), 400

        # Validate image
        is_valid, error_msg = validate_input_image(image)
        if not is_valid:
            return jsonify({'error': error_msg}), 400

        # Detect hands
        detections = hand_detector.detect(image)

        # Draw detections for visualization
        annotated_image = hand_detector.draw_detections(image.copy(), detections)

        response = {
            'detections': detections,
            'image': encode_image_to_base64(annotated_image),
            'timestamp': datetime.now().isoformat(),
            'device': str(device)
        }

        logger.info(f"Hand detection completed. Found {len(detections)} hand(s)")
        return jsonify(response), 200

    except Exception as e:
        logger.error(f"Error in hand detection: {str(e)}")
        return jsonify({'error': str(e)}), 500


@app.route('/slice', methods=['POST'])
def slice_fruit():
    """
    Detect hand motion and slice fruits
    Expects: JSON with 'image' field and optional 'hand_history' (previous detections)
    Returns: Slicing information with affected fruits
    """
    try:
        if fruit_slicer is None or hand_detector is None:
            return jsonify({'error': 'Models not initialized'}), 500

        # Get image from request
        image = _get_image_from_request(request)
        if image is None:
            return jsonify({'error': 'No valid image provided'}), 400

        # Get hand history for motion detection
        hand_history = []
        if request.is_json:
            hand_history = request.get_json().get('hand_history', [])

        # Detect hands
        current_detections = hand_detector.detect(image)

        # Process slicing
        slicing_info = fruit_slicer.process_slice(
            image=image,
            current_detections=current_detections,
            hand_history=hand_history
        )

        # Generate response image
        response_image = slicing_info.get('annotated_image', image)

        response = {
            'sliced': slicing_info.get('sliced', False),
            'affected_fruits': slicing_info.get('affected_fruits', []),
            'hand_motion': slicing_info.get('hand_motion', None),
            'confidence': slicing_info.get('confidence', 0.0),
            'current_detections': current_detections,
            'image': encode_image_to_base64(response_image),
            'timestamp': datetime.now().isoformat()
        }

        logger.info(f"Slice processing completed. Sliced: {slicing_info.get('sliced', False)}")
        return jsonify(response), 200

    except Exception as e:
        logger.error(f"Error in fruit slicing: {str(e)}")
        return jsonify({'error': str(e)}), 500


@app.route('/process-video', methods=['POST'])
def process_video():
    """
    Process video stream frame by frame
    Expects: JSON with 'frames' (list of base64 images)
    Returns: Processed frames with detections and slicing info
    """
    try:
        if hand_detector is None or fruit_slicer is None:
            return jsonify({'error': 'Models not initialized'}), 500

        data = request.get_json()
        if not data:
            return jsonify({'error': 'No JSON data provided'}), 400

        frames = data.get('frames', [])

        if not frames:
            return jsonify({'error': 'No frames provided'}), 400

        processed_results = []
        hand_history = []

        for frame_data in frames:
            # Decode frame
            image = _decode_base64_image(frame_data)
            if image is None:
                continue

            # Detect hands
            detections = hand_detector.detect(image)
            hand_history.append(detections)

            # Keep only last 5 frames for motion tracking
            if len(hand_history) > 5:
                hand_history.pop(0)

            # Process slicing
            slicing_info = fruit_slicer.process_slice(
                image=image,
                current_detections=detections,
                hand_history=hand_history
            )

            # Build result
            frame_result = {
                'detections': detections,
                'sliced': slicing_info.get('sliced', False),
                'affected_fruits': slicing_info.get('affected_fruits', []),
                'image': encode_image_to_base64(slicing_info.get('annotated_image', image))
            }

            processed_results.append(frame_result)

        response = {
            'total_frames': len(processed_results),
            'processed_frames': processed_results,
            'timestamp': datetime.now().isoformat()
        }

        logger.info(f"Video processing completed. Processed {len(processed_results)} frames")
        return jsonify(response), 200

    except Exception as e:
        logger.error(f"Error in video processing: {str(e)}")
        return jsonify({'error': str(e)}), 500


@app.route('/model-info', methods=['GET'])
def model_info():
    """Get information about loaded models"""
    try:
        info = {
            'device': str(device),
            'cuda_available': torch.cuda.is_available(),
            'cuda_device_count': torch.cuda.device_count() if torch.cuda.is_available() else 0,
            'hand_detector': {
                'model': config['hand_detector'].get('model_name', 'N/A'),
                'model_path': config['hand_detector'].get('model_path', 'N/A'),
                'confidence_threshold': config['hand_detector'].get('confidence_threshold', 0.5),
                'loaded': hand_detector is not None
            },
            'fruit_slicer': {
                'motion_threshold': config['fruit_slicer'].get('motion_threshold', 20),
                'max_trail_length': config['fruit_slicer'].get('max_trail_length', 100),
                'loaded': fruit_slicer is not None
            }
        }

        if torch.cuda.is_available():
            info['gpu_memory'] = {
                'total': torch.cuda.get_device_properties(0).total_memory / 1e9,
                'allocated': torch.cuda.memory_allocated(0) / 1e9,
                'reserved': torch.cuda.memory_reserved(0) / 1e9
            }

        return jsonify(info), 200

    except Exception as e:
        logger.error(f"Error getting model info: {str(e)}")
        return jsonify({'error': str(e)}), 500


@app.route('/reset-device', methods=['POST'])
def reset_device():
    """Reset CUDA cache if available"""
    try:
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.reset_peak_memory_stats()
            message = "CUDA cache cleared successfully"
        else:
            message = "CUDA not available"

        logger.info(message)
        return jsonify({'message': message, 'success': True}), 200

    except Exception as e:
        logger.error(f"Error resetting device: {str(e)}")
        return jsonify({'error': str(e), 'success': False}), 500


def _get_image_from_request(request_obj) -> Optional[np.ndarray]:
    """Extract image from Flask request (file or base64)"""
    try:
        # Check for file upload
        if 'image' in request_obj.files:
            file = request_obj.files['image']
            image = Image.open(file.stream)
            return cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)

        # Check for JSON base64
        if request_obj.is_json:
            data = request_obj.get_json()
            if data and 'image' in data:
                return _decode_base64_image(data['image'])

        return None

    except Exception as e:
        logger.error(f"Error extracting image from request: {str(e)}")
        return None


def _decode_base64_image(base64_string: str) -> Optional[np.ndarray]:
    """Decode base64 string to numpy array"""
    try:
        # Handle data URI format
        if ',' in base64_string:
            base64_string = base64_string.split(',')[1]

        image_data = base64.b64decode(base64_string)
        image = Image.open(BytesIO(image_data))
        return cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)

    except Exception as e:
        logger.error(f"Error decoding base64 image: {str(e)}")
        return None


@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors"""
    return jsonify({'error': 'Endpoint not found'}), 404


@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors"""
    logger.error(f"Internal server error: {str(error)}")
    return jsonify({'error': 'Internal server error'}), 500


if __name__ == '__main__':
    try:
        # Initialize models on startup
        initialize_models()

        # Get configuration
        host = config.get('server', {}).get('host', '0.0.0.0')
        port = config.get('server', {}).get('port', 5000)
        debug = config.get('server', {}).get('debug', False)

        logger.info("Starting Fruit Ninja YOLO Backend Server")
        logger.info(f"Server running on {host}:{port}")

        # Run Flask app
        app.run(host=host, port=port, debug=debug, threaded=True)

    except Exception as e:
        logger.error(f"Failed to start server: {str(e)}")
        sys.exit(1)
